package org.jfree.data;

import static org.junit.Assert.*;

import java.util.Objects;

import org.jmock.Mockery;
import org.junit.*;


public class CombineTest {
	private Range testRange;
	private Range temp1;
	private Range temp2;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	
	@Before
	
	public void setUp() throws Exception{
		
	} 
	
	
	@Test
	public void validRangesLower() {
		testRange = new Range(0,0);
		 temp1 = new Range(-1,5);
		 temp2 = new Range (-2,3);
		 testRange = Range.combine(temp1, temp2);
		 assertEquals("value of lower should be -2", -2, testRange.getLowerBound(),0);
	
	}
	
	@Test
	public void validRangesUpper() {
		testRange = new Range(0,0);
		 temp1 = new Range(-1,5);
		 temp2 = new Range (-2,3);
		 testRange = Range.combine(temp1, temp2);
		 assertEquals("value of upper should be 5", 5, testRange.getUpperBound(),0);
	}
	
	@Test
	public void firstRangeIsNull() {
		
		testRange = new Range(0,0);
		temp1 = new Range(-1,5);
		
		testRange = Range.combine(null, temp1);
		assertSame("testRange should be equivalent to temp1", temp1,testRange);
	}
	
	
	@Test
	public void bothRangeAreNull() {
		
		testRange = new Range(0,0);
		
		testRange = Range.combine(null, null);
		assertTrue("range object should be null",  Objects.isNull(testRange));
	}
	
	@Test
	public void secondRangeIsNull() {
		
		testRange = new Range(0,0);
		temp1 = new Range(-1,5);
		
		testRange = Range.combine(temp1, null);
		assertSame("testRange should be equivalent to temp1", temp1,testRange);
	}
	
	@Test
	public void sameUpperValues() {
		
		testRange = new Range (0,0);
		temp1 = new Range(-1,5);
		temp2 = new Range (0, 5);
		
		testRange = Range.combine(temp1, temp2);
		assertEquals("the upper value should be 5", 5, testRange.getUpperBound(),0);
	}
	
	@Test
	public void sameLowerValues() {
		
		testRange = new Range (0,0);
		temp1 = new Range(-1,2);
		temp2 = new Range (-1, 5);
		
		testRange = Range.combine(temp1, temp2);
		assertEquals("the lower value should be -1", -1, testRange.getLowerBound(),0);
	}
	
	@Test
	public void allZeroesLower() {
		testRange = new Range (0,0);
		temp1 = new Range(0,0);
		temp2 = new Range (0,0);
		
		testRange = Range.combine(temp1, temp2);
		assertEquals("the lower value should be 0", 0, testRange.getLowerBound(),0);
		
	}
	
	@Test
	public void allZeroesUpper() {
		
		testRange = new Range (0,0);
		temp1 = new Range(0,0);
		temp2 = new Range (0,0);
		
		testRange = Range.combine(temp1, temp2);
		assertEquals("the upper value should be 0", 0, testRange.getUpperBound(),0);
	}
	
	@After
	
	public void tearDown() throws Exception{
		
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	
}




///**
//     * Creates a new range by combining two existing ranges.
//     * <P>
//     * Note that:
//     * <ul>
//     *   <li>either range can be <code>null</code>, in which case the other
//     *       range is returned;</li>
//     *   <li>if both ranges are <code>null</code> the return value is
//     *       <code>null</code>.</li>
//     * </ul>
//     *
//     * @param range1  the first range (<code>null</code> permitted).
//     * @param range2  the second range (<code>null</code> permitted).
//     *
//     * @return A new range (possibly <code>null</code>).
//     */
//    public static Range combine(Range range1, Range range2) {
//        if (range1 == null) {
//            return range2;
//        }
//        if (range2 == null) {
//            return range1;
//        }
//        double l = Math.min(range1.getLowerBound(), range2.getLowerBound());
//        double u = Math.max(range1.getUpperBound(), range2.getUpperBound());
//        return new Range(l, u);
//    }
//
//**/