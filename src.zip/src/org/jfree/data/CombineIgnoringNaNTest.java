package org.jfree.data;

import static org.junit.Assert.*;

import java.util.Objects;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CombineIgnoringNaNTest {

	private Range testRange;
	private Range temp1;
	private Range temp2;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	
	@Before
	
	public void setUp() throws Exception{
		
	} 
	
	
	@Test
	public void validRangesLower() {
		testRange = new Range(0,0);
		 temp1 = new Range(-1,5);
		 temp2 = new Range (-2,3);
		 testRange = Range.combineIgnoringNaN(temp1, temp2);
		 assertEquals("value of lower should be -2", -2, testRange.getLowerBound(),0);
	
	}
	
	@Test
	public void validRangesUpper() {
		testRange = new Range(0,0);
		 temp1 = new Range(-1,5);
		 temp2 = new Range (-2,3);
		 testRange = Range.combineIgnoringNaN(temp1, temp2);
		 assertEquals("value of upper should be 5", 5, testRange.getUpperBound(),0);
	}
	
	@Test
	public void firstRangeIsNull() {
		
		testRange = new Range(0,0);
		temp1 = new Range(-1,5);
		
		testRange = Range.combineIgnoringNaN(null, temp1);
		assertSame("testRange should be equivalent to temp1", temp1,testRange);
	}
	
	
	@Test
	public void bothRangeAreNull() {
		
		testRange = new Range(0,0);
		
		testRange = Range.combineIgnoringNaN(null, null);
		assertTrue("range object should be null",  Objects.isNull(testRange));
	}
	
	@Test
	public void secondRangeIsNull() {
		
		testRange = new Range(0,0);
		temp1 = new Range(-1,5);
		
		testRange = Range.combineIgnoringNaN(temp1, null);
		assertSame("testRange should be equivalent to temp1", temp1,testRange);
	}
	
	@Test
	public void sameUpperValues() {
		
		testRange = new Range (0,0);
		temp1 = new Range(-1,5);
		temp2 = new Range (0, 5);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the upper value should be 5", 5, testRange.getUpperBound(),0);
	}
	
	@Test
	public void sameLowerValues() {
		
		testRange = new Range (0,0);
		temp1 = new Range(-1,2);
		temp2 = new Range (-1, 5);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be -1", -1, testRange.getLowerBound(),0);
	}
	
	@Test
	public void allZeroesLower() {
		testRange = new Range (0,0);
		temp1 = new Range(0,0);
		temp2 = new Range (0,0);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be 0", 0, testRange.getLowerBound(),0);
		
	}
	
	@Test
	public void allZeroesUpper() {
		
		testRange = new Range (0,0);
		temp1 = new Range(0,0);
		temp2 = new Range (0,0);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the upper value should be 0", 0, testRange.getUpperBound(),0);
	}
	
	@Test
	public void firstOneLowerNaN() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN, 3);
		temp2 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be -3", -3, testRange.getLowerBound(),0);
		
	}
	@Test
	public void firstOneUpperNaN() {
		testRange = new Range(0,0);
		temp1 = new Range(-3,Double.NaN);
		temp2 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be 3", 3, testRange.getUpperBound(),0);
		
	}
	
	@Test
	public void secondOneLowerNaN() {
		testRange = new Range(0,0);
		temp2 = new Range(Double.NaN, 3);
		temp1 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be -3", -3, testRange.getLowerBound(),0);
		
	}
	
	@Test
	public void secondOneUpperNaN() {
		testRange = new Range(0,0);
		temp2 = new Range(-3,Double.NaN);
		temp1 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		assertEquals("the lower value should be 3", 3, testRange.getUpperBound(),0);
		
	}
	@Test
	public void firstRangeNaNLower() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN,Double.NaN);
		temp2 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		
		assertEquals("the range lower should be -3",-3, testRange.getLowerBound(),0);
		
	}
	@Test
	public void firstRangeNaNUpper() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN,Double.NaN);
		temp2 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		
		assertEquals("the range upper should be 3",3, testRange.getUpperBound(),0);
		
	}
	
	@Test
	public void secondRangeNaNLower() {
		testRange = new Range(0,0);
		temp2 = new Range(Double.NaN,Double.NaN);
		temp1 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		
		assertEquals("the range lower should be -3",-3, testRange.getLowerBound(),0);
		
	}
	
	@Test
	public void secondRangeNaNUpper() {
		testRange = new Range(0,0);
		temp2 = new Range(Double.NaN,Double.NaN);
		temp1 = new Range(-3, 3);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		
		assertEquals("the range upper should be 3",3, testRange.getUpperBound(),0);
		
	}
	
	@Test
	public void bothRangeNaN() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN,Double.NaN);
		temp2 = new Range(Double.NaN,Double.NaN);
		
		testRange = Range.combineIgnoringNaN(temp1, temp2);
		
		assertNull("range should be null", testRange);
		
	}
	
	@Test
	public void firstNaNSecondNull() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN,Double.NaN);
		
		testRange = Range.combineIgnoringNaN(temp1, null);
		
		assertNull("range should be null", testRange);
	}
	
	@Test
	public void firstNullSecondNaN() {
		testRange = new Range(0,0);
		temp1 = new Range(Double.NaN,Double.NaN);
		
		testRange = Range.combineIgnoringNaN(null,temp1);
		
		assertNull("range should be null", testRange);
	}
	
	@Test
	public void bothRangeNull() {
		testRange = new Range(0,0);

		testRange = Range.combineIgnoringNaN(null,null);
		assertNull("range should be null", testRange);
		
	}
	
	@After
	
	public void tearDown() throws Exception{
		
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
